# Kumbh Sans

![/images/k01.jpg](/images/k01.jpg)
![/images/k2.jpg](/images/k2.jpg)
![/images/k3.jpg](/images/k3.jpg)
![/images/k4.jpg](/images/k4.jpg)

* [/sources](sources/) contains source UFOs

* [/fonts](fonts/) folder contains font TTFs

# License

Fonts found in this repo are all available under the SIL Open Font License (OFL)
